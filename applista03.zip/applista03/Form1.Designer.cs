﻿namespace applista03
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtname1 = new System.Windows.Forms.TextBox();
            this.txtname3 = new System.Windows.Forms.TextBox();
            this.txtname2 = new System.Windows.Forms.TextBox();
            this.txtNumb2 = new System.Windows.Forms.Label();
            this.txtNumb1 = new System.Windows.Forms.Label();
            this.txtNumb3 = new System.Windows.Forms.Label();
            this.btnsoma = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.lblRsoma = new System.Windows.Forms.Label();
            this.lblRporcentagem = new System.Windows.Forms.Label();
            this.lblRmedia = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtname1
            // 
            this.txtname1.Location = new System.Drawing.Point(130, 179);
            this.txtname1.Name = "txtname1";
            this.txtname1.Size = new System.Drawing.Size(100, 20);
            this.txtname1.TabIndex = 0;
            // 
            // txtname3
            // 
            this.txtname3.Location = new System.Drawing.Point(591, 179);
            this.txtname3.Name = "txtname3";
            this.txtname3.Size = new System.Drawing.Size(100, 20);
            this.txtname3.TabIndex = 1;
            // 
            // txtname2
            // 
            this.txtname2.Location = new System.Drawing.Point(355, 179);
            this.txtname2.Name = "txtname2";
            this.txtname2.Size = new System.Drawing.Size(100, 20);
            this.txtname2.TabIndex = 2;
            // 
            // txtNumb2
            // 
            this.txtNumb2.AutoSize = true;
            this.txtNumb2.Location = new System.Drawing.Point(388, 142);
            this.txtNumb2.Name = "txtNumb2";
            this.txtNumb2.Size = new System.Drawing.Size(45, 13);
            this.txtNumb2.TabIndex = 3;
            this.txtNumb2.Text = "NUMB2";
            // 
            // txtNumb1
            // 
            this.txtNumb1.AutoSize = true;
            this.txtNumb1.Location = new System.Drawing.Point(160, 142);
            this.txtNumb1.Name = "txtNumb1";
            this.txtNumb1.Size = new System.Drawing.Size(45, 13);
            this.txtNumb1.TabIndex = 4;
            this.txtNumb1.Text = "NUMB1";
            // 
            // txtNumb3
            // 
            this.txtNumb3.AutoSize = true;
            this.txtNumb3.Location = new System.Drawing.Point(623, 142);
            this.txtNumb3.Name = "txtNumb3";
            this.txtNumb3.Size = new System.Drawing.Size(45, 13);
            this.txtNumb3.TabIndex = 5;
            this.txtNumb3.Text = "NUMB3";
            // 
            // btnsoma
            // 
            this.btnsoma.Location = new System.Drawing.Point(113, 247);
            this.btnsoma.Name = "btnsoma";
            this.btnsoma.Size = new System.Drawing.Size(130, 37);
            this.btnsoma.TabIndex = 6;
            this.btnsoma.Text = "SOMA";
            this.btnsoma.UseVisualStyleBackColor = true;
            this.btnsoma.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(344, 247);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(129, 37);
            this.btn2.TabIndex = 7;
            this.btn2.Text = "MÈDIA";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(575, 247);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(141, 37);
            this.btn3.TabIndex = 8;
            this.btn3.Text = "PORCENTAGEM";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // lblRsoma
            // 
            this.lblRsoma.AutoSize = true;
            this.lblRsoma.Location = new System.Drawing.Point(127, 346);
            this.lblRsoma.Name = "lblRsoma";
            this.lblRsoma.Size = new System.Drawing.Size(85, 13);
            this.lblRsoma.TabIndex = 9;
            this.lblRsoma.Text = "Resultado Soma";
            // 
            // lblRporcentagem
            // 
            this.lblRporcentagem.AutoSize = true;
            this.lblRporcentagem.Location = new System.Drawing.Point(588, 346);
            this.lblRporcentagem.Name = "lblRporcentagem";
            this.lblRporcentagem.Size = new System.Drawing.Size(121, 13);
            this.lblRporcentagem.TabIndex = 10;
            this.lblRporcentagem.Text = "Resultado Porcentagem";
            // 
            // lblRmedia
            // 
            this.lblRmedia.AutoSize = true;
            this.lblRmedia.Location = new System.Drawing.Point(368, 346);
            this.lblRmedia.Name = "lblRmedia";
            this.lblRmedia.Size = new System.Drawing.Size(87, 13);
            this.lblRmedia.TabIndex = 11;
            this.lblRmedia.Text = "Resultado Média";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(46, 34);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(79, 13);
            this.lblTitulo.TabIndex = 12;
            this.lblTitulo.Text = "EXERCÍCIO 01";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblRmedia);
            this.Controls.Add(this.lblRporcentagem);
            this.Controls.Add(this.lblRsoma);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btnsoma);
            this.Controls.Add(this.txtNumb3);
            this.Controls.Add(this.txtNumb1);
            this.Controls.Add(this.txtNumb2);
            this.Controls.Add(this.txtname2);
            this.Controls.Add(this.txtname3);
            this.Controls.Add(this.txtname1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtname1;
        private System.Windows.Forms.TextBox txtname3;
        private System.Windows.Forms.TextBox txtname2;
        private System.Windows.Forms.Label txtNumb2;
        private System.Windows.Forms.Label txtNumb1;
        private System.Windows.Forms.Label txtNumb3;
        private System.Windows.Forms.Button btnsoma;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Label lblRsoma;
        private System.Windows.Forms.Label lblRporcentagem;
        private System.Windows.Forms.Label lblRmedia;
        private System.Windows.Forms.Label lblTitulo;
    }
}

