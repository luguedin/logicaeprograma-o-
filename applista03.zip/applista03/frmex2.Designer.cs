﻿namespace applista03
{
    partial class frmex2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblvalorapagar = new System.Windows.Forms.Label();
            this.lblvalordolitro = new System.Windows.Forms.Label();
            this.btn01 = new System.Windows.Forms.Button();
            this.lblex = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblvalorapagar
            // 
            this.lblvalorapagar.AutoSize = true;
            this.lblvalorapagar.Location = new System.Drawing.Point(31, 112);
            this.lblvalorapagar.Name = "lblvalorapagar";
            this.lblvalorapagar.Size = new System.Drawing.Size(93, 13);
            this.lblvalorapagar.TabIndex = 2;
            this.lblvalorapagar.Text = "VALOR A PAGAR";
            this.lblvalorapagar.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblvalordolitro
            // 
            this.lblvalordolitro.AutoSize = true;
            this.lblvalordolitro.Location = new System.Drawing.Point(31, 165);
            this.lblvalordolitro.Name = "lblvalordolitro";
            this.lblvalordolitro.Size = new System.Drawing.Size(97, 13);
            this.lblvalordolitro.TabIndex = 3;
            this.lblvalordolitro.Text = "VALOR DO LITRO";
            this.lblvalordolitro.Click += new System.EventHandler(this.lblvalordolitro_Click);
            // 
            // btn01
            // 
            this.btn01.Location = new System.Drawing.Point(34, 274);
            this.btn01.Name = "btn01";
            this.btn01.Size = new System.Drawing.Size(75, 23);
            this.btn01.TabIndex = 4;
            this.btn01.Text = "CALCULAR";
            this.btn01.UseVisualStyleBackColor = true;
            // 
            // lblex
            // 
            this.lblex.AutoSize = true;
            this.lblex.Location = new System.Drawing.Point(27, 26);
            this.lblex.Name = "lblex";
            this.lblex.Size = new System.Drawing.Size(79, 13);
            this.lblex.TabIndex = 5;
            this.lblex.Text = "EXERCÍCIO 02";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(187, 112);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(226, 20);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(187, 158);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(226, 20);
            this.textBox2.TabIndex = 7;
            // 
            // frmex2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 450);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblex);
            this.Controls.Add(this.btn01);
            this.Controls.Add(this.lblvalordolitro);
            this.Controls.Add(this.lblvalorapagar);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "frmex2";
            this.Text = "Frmex1";
            this.Load += new System.EventHandler(this.frmex2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblvalorapagar;
        private System.Windows.Forms.Label lblvalordolitro;
        private System.Windows.Forms.Button btn01;
        private System.Windows.Forms.Label lblex;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
    }
}