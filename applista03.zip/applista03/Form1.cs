﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace applista03
{
    public partial class Form1 : Form
    {
        private const int V = 3;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            //Pegar da textNUMB1.Text);
            float numb1 = float.Parse(txtNumb1.Text);
            float numb3 = float.Parse(txtNumb3.Text);
            float soma;

            //Processamento
            soma = numb1 + numb3;
            
            //Saída
            lblRsoma.Text = "Soma igual a " + soma;

        }

        private void btn2_Click(object sender, EventArgs e)
        {   //Pegar da tela 
            float numb1 = float.Parse(txtNumb1.Text);
            float numb2 = float.Parse(txtNumb2.Text);
            float numb3 = float.Parse(txtNumb3.Text);
            float media;

            //Processamento 
            media = (numb1 + numb2 + numb3) / 3;

            //Saída
            lblRmedia.Text = "Media igual a " + media;

               




        }

        private void btn3_Click(object sender, EventArgs e)
        {   //Pegar da tela
            float numb1 = float.Parse(txtNumb1.Text);
            float numb2 = float.Parse(txtNumb2.Text);
            float numb3 = float.Parse(txtNumb3.Text);
            float total, porcNumb1, porcNumb2, porcNumb3;

            //Processamento
            total = numb1 + numb2 + numb3 //100%
            porcNumb1 = numb1 / total * 100;
            porcNumb2 = numb2 / total * 100;
            porcNumb3 = numb3 / total * 100;

            //Saída 
            lblRporcentagem.Text = "Numb1 é " + porcNumb1 + "% - " + " Numb2 é " + porcNumb2 + "% - " + "Numb3 é" porcNumb3 + "% - ";
        }
    }
}





