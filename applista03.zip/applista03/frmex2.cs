﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace applista03
{
    public partial class frmex2 : Form
    {
        public frmex2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblvalordolitro_Click(object sender, EventArgs e)
        {

        }

        private void frmex2_Load(object sender, EventArgs e)
        {

        }
    }
}
